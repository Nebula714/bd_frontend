<template>
</template>
<script>
const baseURL = 'http://10.128.30.77:9090'
export default {
  baseURL
}
</script>
<style scoped>
</style>
