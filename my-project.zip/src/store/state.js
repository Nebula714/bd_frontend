import { shopInfo } from '../../server/sellers.js'

export default {
  // 是否在加载中
  isLoading: false,
  shopInfo
}
