export default {
  // 得到是否正在加载中
  getLoading: (state) => state.isLoading,
  // 得到商家详细数据
  getShopInfo: (state) => state.shopInfo
}
