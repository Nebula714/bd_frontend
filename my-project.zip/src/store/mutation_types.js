export const SET_LOADING = 'SET_LOADING'
