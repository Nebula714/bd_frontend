import Vue from 'vue'
let VueEvent =new Vue()
export default VueEvent