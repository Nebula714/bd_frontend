<template>
  <div class="split"></div>
</template>
<script>
  export default{}
</script>
<style lang="less" scoped>
  .split{
    width: 100%;
    height: 0.426667rem;
    border-top: 0.013333rem solid rgba(7, 17, 27, 0.1);
    border-bottom: 0.013333rem solid rgba(7, 17, 27, 0.1);
    background-color: #f3f5f7;
  }
</style>
